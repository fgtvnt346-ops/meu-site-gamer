const canvasP = document.getElementById("pongGame");
const ctxP = canvasP.getContext("2d");

const user = { x: 0, y: canvasP.height/2 - 50, width: 10, height: 100, color: "WHITE", score: 0 };
const com = { x: canvasP.width-10, y: canvasP.height/2 - 50, width: 10, height: 100, color: "WHITE", score: 0 };
const ball = { x: canvasP.width/2, y: canvasP.height/2, radius: 10, speed: 5, velocityX: 5, velocityY: 5, color: "WHITE" };

function drawRect(x,y,w,h,color){ ctxP.fillStyle = color; ctxP.fillRect(x,y,w,h); }
function drawCircle(x,y,r,color){ ctxP.fillStyle = color; ctxP.beginPath(); ctxP.arc(x,y,r,0,Math.PI*2,false); ctxP.closePath(); ctxP.fill(); }
function drawText(text,x,y,color){ ctxP.fillStyle = color; ctxP.font = "45px Arial"; ctxP.fillText(text,x,y); }

canvasP.addEventListener("mousemove", movePaddle);
function movePaddle(evt){ let rect = canvasP.getBoundingClientRect(); user.y = evt.clientY - rect.top - user.height/2; }

function collision(b,p){
  p.top = p.y; p.bottom = p.y + p.height; p.left = p.x; p.right = p.x + p.width;
  b.top = b.y - b.radius; b.bottom = b.y + b.radius; b.left = b.x - b.radius; b.right = b.x + b.radius;
  return b.right > p.left && b.bottom > p.top && b.left < p.right && b.top < p.bottom;
}

function resetBall(){ ball.x = canvasP.width/2; ball.y = canvasP.height/2; ball.speed = 5; ball.velocityX = -ball.velocityX; }

function update(){
  ball.x += ball.velocityX;
  ball.y += ball.velocityY;

  if(ball.y + ball.radius > canvasP.height || ball.y - ball.radius < 0){ ball.velocityY = -ball.velocityY; }

  let player = (ball.x < canvasP.width/2)? user : com;
  if(collision(ball,player)){
    let collidePoint = ball.y - (player.y + player.height/2);
    collidePoint = collidePoint / (player.height/2);
    let angleRad = collidePoint * Math.PI/4;
    let direction = (ball.x < canvasP.width/2)? 1 : -1;
    ball.velocityX = direction * ball.speed * Math.cos(angleRad);
    ball.velocityY = ball.speed * Math.sin(angleRad);
    ball.speed += 0.5;
  }

  if(ball.x - ball.radius < 0){ com.score++; resetBall(); }
  else if(ball.x + ball.radius > canvasP.width){ user.score++; resetBall(); }

  com.y += (ball.y - (com.y + com.height/2)) * 0.1;
}

function render(){
  drawRect(0,0,canvasP.width,canvasP.height,"BLACK");
  drawText(user.score, canvasP.width/4, canvasP.height/5, "WHITE");
  drawText(com.score, 3*canvasP.width/4, canvasP.height/5, "WHITE");
  drawRect(user.x, user.y, user.width, user.height, user.color);
  drawRect(com.x, com.y, com.width, com.height, com.color);
  drawCircle(ball.x, ball.y, ball.radius, ball.color);
}

function game(){ update(); render(); }
setInterval(game,1000/50);
