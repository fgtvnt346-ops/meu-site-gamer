const cvs = document.getElementById("flappyGame");
const ctxF = cvs.getContext("2d");

let frames = 0;
const DEGREE = Math.PI/180;

// Load sprite
let bird = { x: 50, y: 150, w: 30, h: 30, radius: 15, gravity: 0.25, jump: 4.6, speed: 0, rotation: 0 };

document.addEventListener("keydown", flap);
function flap(){ bird.speed = -bird.jump; }

let pipes = [];
pipes[0] = { x: cvs.width, y: 0 };

function draw(){
  ctxF.fillStyle = "#70c5ce";
  ctxF.fillRect(0,0,cvs.width,cvs.height);

  for(let i = 0; i < pipes.length; i++){
    let pipeWidth = 50;
    let gap = 120;
    let pipeHeight = 100 + Math.floor(Math.random()*150);

    ctxF.fillStyle = "green";
    ctxF.fillRect(pipes[i].x, pipes[i].y, pipeWidth, pipeHeight);
    ctxF.fillRect(pipes[i].x, pipeHeight+gap, pipeWidth, cvs.height);

    pipes[i].x--;

    if(pipes[i].x == 200){ pipes.push({x:cvs.width,y:0}); }

    if(bird.x + bird.radius > pipes[i].x && bird.x - bird.radius < pipes[i].x + pipeWidth && (bird.y - bird.radius < pipeHeight || bird.y + bird.radius > pipeHeight+gap)){
      clearInterval(loop); alert("Game Over!");
    }
  }

  ctxF.fillStyle = "yellow";
  ctxF.beginPath();
  ctxF.arc(bird.x, bird.y, bird.radius, 0, Math.PI*2);
  ctxF.closePath();
  ctxF.fill();
}

function update(){
  bird.speed += bird.gravity;
  bird.y += bird.speed;

  if(bird.y + bird.radius >= cvs.height){ clearInterval(loop); alert("Game Over!"); }
}

function loop(){
  update();
  draw();
  frames++;
}
setInterval(loop,1000/50);
