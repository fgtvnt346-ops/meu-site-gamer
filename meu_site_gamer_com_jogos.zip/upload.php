<?php
$pasta = "uploads/";
if (!is_dir($pasta)) {
    mkdir($pasta, 0777, true);
}
if (isset($_FILES['arquivo'])) {
    $arquivo = $_FILES['arquivo'];
    $nome = basename($arquivo["name"]);
    $destino = $pasta . $nome;
    if (move_uploaded_file($arquivo["tmp_name"], $destino)) {
        echo "✅ Arquivo enviado com sucesso: " . $nome;
    } else {
        echo "❌ Erro ao enviar o arquivo.";
    }
} else {
    echo "Nenhum arquivo selecionado.";
}
?>